# DriveSync

DriveSync is a Django-based car booking and fleet sharing prototype with separate
dashboards for drivers, car owners, and administrators.

## Features

- User registration and login with role-based dashboards.
- Drivers can browse available cars and create bookings.
- Owners can list cars, update availability, and review booking activity.
- Administrators can view users, cars, revenue, and booking status.
- Includes a small machine learning regression script using `train.csv`.

## Setup

1. Install Python dependencies for Django.
2. Install frontend dependencies with `npm install`.
3. Copy `.env.example` to `.env` and replace the placeholder values.
4. Run database migrations.
5. Optionally seed demo data with the `seed_data` management command.
6. Start the Django development server.

## Security Notes

This upload package intentionally excludes local/private generated files such as
`db.sqlite3`, `.env` files, `node_modules/`, Python bytecode, media uploads, and
generated model binaries. See `GOOGLE_DRIVE_UPLOAD_NOTES.md` for the full list.

Do not share a local database or real environment file publicly.
