from django.core.management.base import BaseCommand
from django.contrib.auth.models import User
from core.models import UserProfile, Car, Booking
from django.utils import timezone
from datetime import timedelta
import os
import random


class Command(BaseCommand):
    help = 'Seed the database with sample DriveSync data'

    def handle(self, *args, **kwargs):
        self.stdout.write('🚗 Seeding DriveSync database...')

        # --- ADMIN ---
        admin, _ = User.objects.get_or_create(username='admin')
        admin_password = os.environ.get("DRIVESYNC_DEMO_ADMIN_PASSWORD", "change-me-admin")
        user_password = os.environ.get("DRIVESYNC_DEMO_USER_PASSWORD", "change-me-user")
        admin.set_password(admin_password)
        admin.first_name = 'Super'
        admin.last_name = 'Admin'
        admin.email = 'admin@drivesync.com'
        admin.is_staff = True
        admin.is_superuser = True
        admin.save()
        UserProfile.objects.get_or_create(user=admin, defaults={
            'role': 'admin', 'department': 'IT', 'employee_id': 'EMP001',
            'phone': '9000000001', 'avatar_initial': 'SA'
        })

        # --- OWNERS ---
        owners_data = [
            ('owner1', 'Priya', 'Sharma', 'priya@company.com', 'Finance', 'EMP002'),
            ('owner2', 'Rahul', 'Verma', 'rahul@company.com', 'HR', 'EMP003'),
            ('owner3', 'Sneha', 'Nair', 'sneha@company.com', 'Marketing', 'EMP004'),
        ]
        owners = []
        for uname, fname, lname, email, dept, eid in owners_data:
            u, _ = User.objects.get_or_create(username=uname)
            u.set_password(user_password)
            u.first_name = fname; u.last_name = lname; u.email = email; u.save()
            initials = (fname[0] + lname[0]).upper()
            UserProfile.objects.get_or_create(user=u, defaults={
                'role': 'owner', 'department': dept,
                'employee_id': eid, 'phone': f'90000000{eid[-2:]}',
                'avatar_initial': initials
            })
            owners.append(u)

        # --- DRIVERS ---
        drivers_data = [
            ('driver1', 'Amit', 'Kumar', 'amit@company.com', 'Operations', 'EMP005'),
            ('driver2', 'Suresh', 'Patel', 'suresh@company.com', 'Logistics', 'EMP006'),
            ('driver3', 'Ravi', 'Singh', 'ravi@company.com', 'Sales', 'EMP007'),
        ]
        drivers = []
        for uname, fname, lname, email, dept, eid in drivers_data:
            u, _ = User.objects.get_or_create(username=uname)
            u.set_password(user_password)
            u.first_name = fname; u.last_name = lname; u.email = email; u.save()
            initials = (fname[0] + lname[0]).upper()
            UserProfile.objects.get_or_create(user=u, defaults={
                'role': 'driver', 'department': dept,
                'employee_id': eid, 'phone': f'91000000{eid[-2:]}',
                'avatar_initial': initials
            })
            drivers.append(u)

        # --- CARS ---
        cars_data = [
            (owners[0], 'Toyota', 'Innova', 2022, 'White', 'MH01AB1234', 'petrol', 7, 200, 'Spacious SUV, well maintained'),
            (owners[0], 'Honda', 'City', 2021, 'Silver', 'MH01CD5678', 'petrol', 5, 150, 'Comfortable sedan for city trips'),
            (owners[1], 'Hyundai', 'Creta', 2023, 'Blue', 'MH02EF9012', 'diesel', 5, 180, 'Great mileage, perfect for long routes'),
            (owners[1], 'Tata', 'Nexon', 2022, 'Red', 'MH02GH3456', 'electric', 5, 170, 'EV — zero emissions, smooth ride'),
            (owners[2], 'Maruti', 'Swift', 2020, 'Grey', 'MH03IJ7890', 'petrol', 5, 120, 'Fuel-efficient hatchback'),
            (owners[2], 'Kia', 'Seltos', 2023, 'Black', 'MH03KL1234', 'diesel', 5, 190, 'Premium compact SUV'),
        ]
        cars = []
        for owner, make, model, year, color, plate, fuel, seats, rate, desc in cars_data:
            car, _ = Car.objects.get_or_create(license_plate=plate, defaults={
                'owner': owner, 'make': make, 'model': model, 'year': year,
                'color': color, 'fuel_type': fuel, 'seating_capacity': seats,
                'rate_per_hour': rate, 'description': desc, 'status': 'available'
            })
            cars.append(car)

        # --- BOOKINGS ---
        now = timezone.now()
        bookings_data = [
            (drivers[0], cars[0], now - timedelta(days=5, hours=3), now - timedelta(days=5), 'completed', 'Client airport pickup'),
            (drivers[1], cars[1], now - timedelta(days=3, hours=2), now - timedelta(days=3), 'completed', 'Office supply run'),
            (drivers[2], cars[2], now - timedelta(days=1, hours=4), now - timedelta(days=1), 'completed', 'Customer visit'),
            (drivers[0], cars[3], now + timedelta(hours=2), now + timedelta(hours=6), 'confirmed', 'Sales meeting'),
            (drivers[1], cars[4], now + timedelta(days=1), now + timedelta(days=1, hours=3), 'confirmed', 'Branch visit'),
        ]
        for driver, car, start, end, status, purpose in bookings_data:
            if not Booking.objects.filter(driver=driver, car=car, start_time=start).exists():
                b = Booking(driver=driver, car=car, start_time=start, end_time=end,
                            status=status, purpose=purpose)
                b.save()
                if status in ['active', 'confirmed']:
                    car.status = 'booked'
                    car.save()

        self.stdout.write(self.style.SUCCESS('✅ Database seeded successfully!'))
        self.stdout.write('')
        self.stdout.write('👤 Test Accounts:')
        self.stdout.write('  Admin username:  admin')
        self.stdout.write('  Owner username:  owner1')
        self.stdout.write('  Driver username: driver1')
        self.stdout.write('  Passwords come from DRIVESYNC_DEMO_ADMIN_PASSWORD and DRIVESYNC_DEMO_USER_PASSWORD.')
