from django.db import models
from django.contrib.auth.models import User


class UserProfile(models.Model):
    ROLE_CHOICES = [
        ('owner', 'Car Owner'),
        ('driver', 'Company Driver'),
        ('admin', 'Administrator'),
    ]
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='profile')
    role = models.CharField(max_length=20, choices=ROLE_CHOICES, default='driver')
    phone = models.CharField(max_length=20, blank=True)
    department = models.CharField(max_length=100, blank=True)
    employee_id = models.CharField(max_length=50, blank=True)
    avatar_initial = models.CharField(max_length=2, blank=True)

    def __str__(self):
        return f"{self.user.get_full_name()} ({self.role})"

    def save(self, *args, **kwargs):
        if not self.avatar_initial and self.user.first_name:
            self.avatar_initial = (self.user.first_name[0] + (self.user.last_name[0] if self.user.last_name else '')).upper()
        super().save(*args, **kwargs)


class Car(models.Model):
    STATUS_CHOICES = [
        ('available', 'Available'),
        ('booked', 'Booked'),
        ('maintenance', 'Under Maintenance'),
    ]
    FUEL_CHOICES = [
        ('petrol', 'Petrol'),
        ('diesel', 'Diesel'),
        ('electric', 'Electric'),
        ('hybrid', 'Hybrid'),
    ]
    owner = models.ForeignKey(User, on_delete=models.CASCADE, related_name='cars')
    make = models.CharField(max_length=100)
    model = models.CharField(max_length=100)
    year = models.IntegerField()
    color = models.CharField(max_length=50)
    license_plate = models.CharField(max_length=20, unique=True)
    fuel_type = models.CharField(max_length=20, choices=FUEL_CHOICES, default='petrol')
    seating_capacity = models.IntegerField(default=5)
    rate_per_hour = models.DecimalField(max_digits=8, decimal_places=2, default=150.00)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='available')
    description = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.year} {self.make} {self.model} ({self.license_plate})"

    def get_color_class(self):
        color_map = {
            'white': '#f8fafc', 'black': '#1e293b', 'silver': '#94a3b8',
            'red': '#ef4444', 'blue': '#3b82f6', 'grey': '#6b7280',
            'gray': '#6b7280', 'green': '#22c55e', 'yellow': '#eab308',
        }
        return color_map.get(self.color.lower(), '#8b5cf6')


class Booking(models.Model):
    STATUS_CHOICES = [
        ('pending', 'Pending'),
        ('confirmed', 'Confirmed'),
        ('active', 'Active'),
        ('completed', 'Completed'),
        ('cancelled', 'Cancelled'),
    ]
    driver = models.ForeignKey(User, on_delete=models.CASCADE, related_name='bookings')
    car = models.ForeignKey(Car, on_delete=models.CASCADE, related_name='bookings')
    start_time = models.DateTimeField()
    end_time = models.DateTimeField()
    purpose = models.CharField(max_length=255, blank=True)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending')
    total_cost = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    notes = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.driver.get_full_name()} → {self.car} [{self.status}]"

    def save(self, *args, **kwargs):
        if self.start_time and self.end_time:
            duration_hours = (self.end_time - self.start_time).total_seconds() / 3600
            self.total_cost = round(duration_hours * float(self.car.rate_per_hour), 2)
        super().save(*args, **kwargs)

    def duration_hours(self):
        if self.start_time and self.end_time:
            return round((self.end_time - self.start_time).total_seconds() / 3600, 1)
        return 0


class Feedback(models.Model):
    booking = models.OneToOneField(Booking, on_delete=models.CASCADE, related_name='feedback')
    rating = models.IntegerField(default=5)
    comment = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Feedback for Booking #{self.booking.id} — {self.rating}★"
