from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login, logout, authenticate
from django.contrib.auth.decorators import login_required
from django.views.decorators.csrf import ensure_csrf_cookie
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth.models import User
from django.contrib import messages
from django.db.models import Sum, Count, Avg, Q
from django.utils import timezone
from django.http import JsonResponse
from .models import UserProfile, Car, Booking, Feedback
from .forms import RegisterForm, CarListingForm, BookingForm
import json


def landing(request):
    if request.user.is_authenticated:
        return redirect('dashboard')
    stats = {
        'cars': Car.objects.filter(status='available').count(),
        'drivers': UserProfile.objects.filter(role='driver').count(),
        'bookings': Booking.objects.filter(status='completed').count(),
        'owners': UserProfile.objects.filter(role='owner').count(),
    }
    return render(request, 'landing.html', {'stats': stats})


@ensure_csrf_cookie
def register_view(request):
    if request.user.is_authenticated:
        return redirect('dashboard')
    if request.method == 'POST':
        form = RegisterForm(request.POST)
        if form.is_valid():
            user = form.save(commit=False)
            user.first_name = form.cleaned_data['first_name']
            user.last_name = form.cleaned_data['last_name']
            user.email = form.cleaned_data['email']
            user.save()
            initials = (user.first_name[0] + (user.last_name[0] if user.last_name else '')).upper()
            UserProfile.objects.create(
                user=user,
                role=form.cleaned_data['role'],
                phone=form.cleaned_data.get('phone', ''),
                department=form.cleaned_data.get('department', ''),
                employee_id=form.cleaned_data.get('employee_id', ''),
                avatar_initial=initials,
            )
            login(request, user)
            messages.success(request, f"Welcome to DriveSync, {user.first_name}!")
            return redirect('dashboard')
    else:
        form = RegisterForm()
    return render(request, 'register.html', {'form': form})


@ensure_csrf_cookie
def login_view(request):
    if request.user.is_authenticated:
        return redirect('dashboard')
    if request.method == 'POST':
        form = AuthenticationForm(data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            messages.success(request, f"Welcome back, {user.first_name or user.username}!")
            return redirect('dashboard')
        else:
            messages.error(request, "Invalid username or password.")
    else:
        form = AuthenticationForm()
    return render(request, 'login.html', {'form': form})


def logout_view(request):
    logout(request)
    return redirect('landing')


@login_required
def dashboard(request):
    profile = get_object_or_404(UserProfile, user=request.user)
    if profile.role == 'driver':
        return redirect('driver_dashboard')
    elif profile.role == 'owner':
        return redirect('owner_dashboard')
    elif profile.role == 'admin' or request.user.is_staff:
        return redirect('admin_dashboard')
    return redirect('driver_dashboard')


@login_required
@ensure_csrf_cookie
def driver_dashboard(request):
    profile = get_object_or_404(UserProfile, user=request.user)
    available_cars = Car.objects.filter(status='available').select_related('owner', 'owner__profile')
    my_bookings = Booking.objects.filter(driver=request.user).select_related('car', 'car__owner').order_by('-created_at')

    now = timezone.now()
    active_booking = my_bookings.filter(status='active').first()
    upcoming = my_bookings.filter(status='confirmed', start_time__gte=now).first()

    total_spent = my_bookings.filter(status='completed').aggregate(s=Sum('total_cost'))['s'] or 0
    completed_count = my_bookings.filter(status='completed').count()

    context = {
        'profile': profile,
        'available_cars': available_cars,
        'my_bookings': my_bookings[:10],
        'active_booking': active_booking,
        'upcoming_booking': upcoming,
        'total_spent': total_spent,
        'completed_count': completed_count,
    }
    return render(request, 'dashboard_driver.html', context)


@login_required
@ensure_csrf_cookie
def owner_dashboard(request):
    profile = get_object_or_404(UserProfile, user=request.user)
    my_cars = Car.objects.filter(owner=request.user)
    car_bookings = Booking.objects.filter(car__owner=request.user).select_related('driver', 'car').order_by('-created_at')

    total_earned = car_bookings.filter(status='completed').aggregate(s=Sum('total_cost'))['s'] or 0
    total_bookings = car_bookings.count()
    active_count = my_cars.filter(status='booked').count()

    if request.method == 'POST':
        form = CarListingForm(request.POST)
        if form.is_valid():
            car = form.save(commit=False)
            car.owner = request.user
            car.save()
            messages.success(request, f"🚗 {car.make} {car.model} listed successfully!")
            return redirect('owner_dashboard')
    else:
        form = CarListingForm()

    context = {
        'profile': profile,
        'my_cars': my_cars,
        'car_bookings': car_bookings[:10],
        'total_earned': total_earned,
        'total_bookings': total_bookings,
        'active_count': active_count,
        'form': form,
    }
    return render(request, 'dashboard_owner.html', context)


@login_required
@ensure_csrf_cookie
def admin_dashboard(request):
    profile = get_object_or_404(UserProfile, user=request.user)
    all_users = UserProfile.objects.select_related('user').all()
    all_cars = Car.objects.select_related('owner').all()
    all_bookings = Booking.objects.select_related('driver', 'car').order_by('-created_at')

    total_revenue = all_bookings.filter(status='completed').aggregate(s=Sum('total_cost'))['s'] or 0
    total_bookings = all_bookings.count()
    available_cars = all_cars.filter(status='available').count()
    active_drivers = all_bookings.filter(status='active').values('driver').distinct().count()

    role_dist = {
        'owners': UserProfile.objects.filter(role='owner').count(),
        'drivers': UserProfile.objects.filter(role='driver').count(),
        'admins': UserProfile.objects.filter(role='admin').count(),
    }

    context = {
        'profile': profile,
        'all_users': all_users,
        'all_cars': all_cars[:10],
        'all_bookings': all_bookings[:15],
        'total_revenue': total_revenue,
        'total_bookings': total_bookings,
        'available_cars': available_cars,
        'active_drivers': active_drivers,
        'total_cars': all_cars.count(),
        'total_users': all_users.count(),
        'role_dist': role_dist,
    }
    return render(request, 'dashboard_admin.html', context)


@login_required
@ensure_csrf_cookie
def book_car(request, car_id):
    car = get_object_or_404(Car, id=car_id, status='available')
    if request.method == 'POST':
        form = BookingForm(request.POST)
        if form.is_valid():
            booking = form.save(commit=False)
            booking.driver = request.user
            booking.car = car
            booking.status = 'confirmed'
            booking.save()
            car.status = 'booked'
            car.save()
            messages.success(request, f"✅ Booking confirmed for {car.make} {car.model}!")
            return redirect('driver_dashboard')
        else:
            messages.error(request, "Please fix the errors below.")
    else:
        form = BookingForm()
    return render(request, 'book_car.html', {'form': form, 'car': car})


@login_required
def cancel_booking(request, booking_id):
    booking = get_object_or_404(Booking, id=booking_id, driver=request.user)
    if booking.status in ['pending', 'confirmed']:
        booking.status = 'cancelled'
        booking.save()
        booking.car.status = 'available'
        booking.car.save()
        messages.success(request, "Booking cancelled successfully.")
    return redirect('driver_dashboard')


@login_required
def delete_car(request, car_id):
    car = get_object_or_404(Car, id=car_id, owner=request.user)
    if car.status != 'booked':
        car.delete()
        messages.success(request, "Car removed from listings.")
    else:
        messages.error(request, "Cannot remove a currently booked car.")
    return redirect('owner_dashboard')


@login_required
def toggle_car_status(request, car_id):
    car = get_object_or_404(Car, id=car_id, owner=request.user)
    if car.status == 'available':
        car.status = 'maintenance'
    elif car.status == 'maintenance':
        car.status = 'available'
    car.save()
    messages.success(request, f"Car status updated to {car.get_status_display()}.")
    return redirect('owner_dashboard')


@login_required
def update_booking_status(request, booking_id):
    """Admin can update booking status"""
    profile = get_object_or_404(UserProfile, user=request.user)
    if not (profile.role == 'admin' or request.user.is_staff):
        return redirect('dashboard')
    booking = get_object_or_404(Booking, id=booking_id)
    new_status = request.POST.get('status')
    if new_status in dict(Booking.STATUS_CHOICES):
        booking.status = new_status
        booking.save()
        if new_status == 'completed':
            booking.car.status = 'available'
            booking.car.save()
        messages.success(request, f"Booking #{booking.id} updated to {new_status}.")
    return redirect('admin_dashboard')
