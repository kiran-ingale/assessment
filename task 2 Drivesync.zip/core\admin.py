from django.contrib import admin
from .models import UserProfile, Car, Booking, Feedback

@admin.register(UserProfile)
class UserProfileAdmin(admin.ModelAdmin):
    list_display = ['user', 'role', 'department', 'employee_id', 'phone']
    list_filter = ['role', 'department']
    search_fields = ['user__username', 'user__email', 'employee_id']

@admin.register(Car)
class CarAdmin(admin.ModelAdmin):
    list_display = ['make', 'model', 'year', 'license_plate', 'owner', 'status', 'rate_per_hour']
    list_filter = ['status', 'fuel_type']
    search_fields = ['make', 'model', 'license_plate', 'owner__username']

@admin.register(Booking)
class BookingAdmin(admin.ModelAdmin):
    list_display = ['driver', 'car', 'start_time', 'end_time', 'status', 'total_cost']
    list_filter = ['status']
    search_fields = ['driver__username', 'car__license_plate']

@admin.register(Feedback)
class FeedbackAdmin(admin.ModelAdmin):
    list_display = ['booking', 'rating', 'created_at']
    list_filter = ['rating']
