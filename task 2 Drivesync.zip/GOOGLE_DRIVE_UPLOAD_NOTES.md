# Google Drive Upload Notes

Use the prepared upload archive instead of sharing the full working folder.

Excluded from the review package:

- `db.sqlite3`: contains Django user records, password hashes, profile fields, bookings, and car records.
- `node_modules/`: dependency cache that can be reinstalled from `package-lock.json`.
- `__pycache__/` and `*.pyc`: generated Python bytecode.
- `.env` files: local secrets and deployment values.
- `media/`: user-uploaded files, if present.
- `*.joblib`: generated model binaries; regenerate with `python regression.py`.

Before any hosted deployment, set real environment values for `DJANGO_SECRET_KEY`,
`DJANGO_DEBUG`, `DJANGO_ALLOWED_HOSTS`, `DRIVESYNC_DEMO_ADMIN_PASSWORD`, and
`DRIVESYNC_DEMO_USER_PASSWORD`.
