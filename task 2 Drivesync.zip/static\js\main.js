// DriveSync — Main JavaScript

document.addEventListener('DOMContentLoaded', () => {

  // ── MODAL HANDLING ──
  document.querySelectorAll('[data-modal-open]').forEach(btn => {
    btn.addEventListener('click', () => {
      const id = btn.getAttribute('data-modal-open');
      const modal = document.getElementById(id);
      if (modal) { modal.classList.add('open'); document.body.style.overflow = 'hidden'; }
    });
  });

  document.querySelectorAll('[data-modal-close], .modal-overlay').forEach(el => {
    el.addEventListener('click', (e) => {
      if (e.target === el) {
        document.querySelectorAll('.modal-overlay').forEach(m => m.classList.remove('open'));
        document.body.style.overflow = '';
      }
    });
  });

  // ── SMOOTH SCROLL for sidebar links ──
  document.querySelectorAll('a[href^="#"]').forEach(a => {
    a.addEventListener('click', e => {
      const target = document.querySelector(a.getAttribute('href'));
      if (target) {
        e.preventDefault();
        target.scrollIntoView({ behavior: 'smooth', block: 'start' });
        // Update active state
        document.querySelectorAll('.sidebar-link').forEach(l => l.classList.remove('active'));
        a.classList.add('active');
      }
    });
  });

  // ── AUTO-DISMISS ALERTS ──
  document.querySelectorAll('.alert[data-auto-dismiss]').forEach(el => {
    setTimeout(() => {
      el.style.transition = 'opacity 0.5s';
      el.style.opacity = '0';
      setTimeout(() => el.remove(), 500);
    }, 3000);
  });

  // ── CARD HOVER ANIMATION ──
  document.querySelectorAll('.car-card, .stat-card, .feature-card').forEach(card => {
    card.addEventListener('mouseenter', () => {
      card.style.transition = 'all 0.3s ease';
    });
  });

  // ── ACTIVE SIDEBAR BASED ON SCROLL ──
  const sections = document.querySelectorAll('[id]');
  const sidebarLinks = document.querySelectorAll('.sidebar-link');

  if (sections.length && sidebarLinks.length) {
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          const id = entry.target.id;
          sidebarLinks.forEach(l => {
            l.classList.toggle('active', l.getAttribute('href') === `#${id}`);
          });
        }
      });
    }, { threshold: 0.3, rootMargin: '-70px 0px 0px 0px' });

    sections.forEach(s => observer.observe(s));
  }

  // ── NUMBER COUNTER ANIMATION for stats ──
  const statValues = document.querySelectorAll('.stat-value, .hstat-value');
  const animateValue = (el) => {
    const raw = el.textContent.replace(/[^0-9.]/g, '');
    const target = parseFloat(raw);
    if (!target || isNaN(target)) return;
    const prefix = el.textContent.match(/^[^0-9]*/)[0];
    const suffix = el.textContent.match(/[^0-9.]*$/)[0];
    let start = 0;
    const duration = 1200;
    const step = (timestamp) => {
      if (!start) start = timestamp;
      const progress = Math.min((timestamp - start) / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 3);
      el.textContent = prefix + Math.round(eased * target).toLocaleString('en-IN') + suffix;
      if (progress < 1) requestAnimationFrame(step);
    };
    requestAnimationFrame(step);
  };

  const counterObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        animateValue(entry.target);
        counterObserver.unobserve(entry.target);
      }
    });
  }, { threshold: 0.5 });

  statValues.forEach(el => counterObserver.observe(el));

  console.log('%c🚗 DriveSync Loaded', 'color:#6366f1;font-size:1.2rem;font-weight:bold;');
});
